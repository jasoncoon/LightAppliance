/*
    The purpose of this file is to give a unique header filename
    to be included in the Arduino Sketch, so this particular library
    can be found during linking
*/
#include "SmartMatrix.h"
